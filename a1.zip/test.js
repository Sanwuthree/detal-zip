const cm=require("./compare");
cm.detal("detal2.zip","detal1.zip","out.zip")