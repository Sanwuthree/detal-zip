# detal-zip

### compare two zip file, and make detal zip

### Installation
~~~
npm install detal-zip
~~~
## Useage
~~~ javascript
const cm=require("./compare");
cm.detal("detal2.zip","detal1.zip","out.zip")
~~~